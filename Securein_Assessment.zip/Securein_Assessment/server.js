import express from 'express';
import { MongoClient } from 'mongodb';
import swaggerUi from 'swagger-ui-express';
import swaggerJsdoc from 'swagger-jsdoc';

const app = express();
const uri = "mongodb://localhost:27017/";
const dbName = "NVD";
const collectionName = "cve";

// Swagger setup
const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'CVE API',
      version: '1.0.0',
      description: 'API documentation for the CVE management system',
    },
  },
  apis: ['./index.js'], // Path to the API docs
};
const specs = swaggerJsdoc(options);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));

// Connect to MongoDB
let client;
(async () => {
  client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
  console.log('Connected to MongoDB');
})();

/**
 * @swagger
 * /api/cve/{cveId}:
 *   get:
 *     summary: Fetch CVE details by CVE ID
 *     parameters:
 *       - in: path
 *         name: cveId
 *         schema:
 *           type: string
 *         required: true
 *         description: The CVE ID to fetch details for
 *     responses:
 *       200:
 *         description: CVE details
 *       404:
 *         description: CVE not found
 *       500:
 *         description: Internal server error
 */
app.get('/api/cve/:cveId', async (req, res) => {
  const cveId = req.params.cveId;
  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  try {
    const cveDetails = await collection.findOne({ "cveId": cveId });
    if (!cveDetails) {
      return res.status(404).json({ error: "CVE not found" });
    }
    return res.json(cveDetails);
  } catch (error) {
    console.error('Error fetching CVE details:', error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * @swagger
 * /api/cve/year/{year}:
 *   get:
 *     summary: Fetch CVE details by year
 *     parameters:
 *       - in: path
 *         name: year
 *         schema:
 *           type: string
 *         required: true
 *         description: The year to fetch CVE details for
 *     responses:
 *       200:
 *         description: CVE details for the specified year
 *       500:
 *         description: Internal server error
 */
app.get('/api/cve/year/:year', async (req, res) => {
  const year = req.params.year;
  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  try {
    const cveDetails = await collection.find({
      "publishedDate": { $regex: `^${year}` }
    }).toArray();
    return res.json(cveDetails);
  } catch (error) {
    console.error('Error fetching CVE details by year:', error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * @swagger
 * /api/cve/score/{score}:
 *   get:
 *     summary: Fetch CVE details by score
 *     parameters:
 *       - in: path
 *         name: score
 *         schema:
 *           type: number
 *         required: true
 *         description: The CVSS score to fetch CVE details for
 *     responses:
 *       200:
 *         description: CVE details for the specified score
 *       500:
 *         description: Internal server error
 */
app.get('/api/cve/score/:score', async (req, res) => {
  const score = parseFloat(req.params.score);
  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  try {
    const cveDetails = await collection.find({
      $or: [
        { "metrics.cvssMetricV2.cvssData.baseScore": score },
        { "metrics.cvssMetricV3.cvssData.baseScore": score }
      ]
    }).toArray();
    return res.json(cveDetails);
  } catch (error) {
    console.error('Error fetching CVE details by score:', error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * @swagger
 * /api/cve/modified/{days}:
 *   get:
 *     summary: Fetch CVE details modified in the last N days
 *     parameters:
 *       - in: path
 *         name: days
 *         schema:
 *           type: integer
 *         required: true
 *         description: The number of days to look back for modified CVE details
 *     responses:
 *       200:
 *         description: CVE details modified in the last N days
 *       500:
 *         description: Internal server error
 */
app.get('/api/cve/modified/:days', async (req, res) => {
  const days = parseInt(req.params.days);
  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  const date = new Date();
  date.setDate(date.getDate() - days);

  try {
    const cveDetails = await collection.find({
      "lastModifiedDate": { $gte: date.toISOString() }
    }).toArray();
    return res.json(cveDetails);
  } catch (error) {
    console.error('Error fetching CVE details modified in last N days:', error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * @swagger
 * /api/cve:
 *   get:
 *     summary: Fetch paginated CVE details
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *         description: The number of records per page (default is 10)
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *         description: The page number (default is 1)
 *       - in: query
 *         name: sortField
 *         schema:
 *           type: string
 *         description: The field to sort by (default is 'publishedDate')
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *         description: The sort order, 'asc' for ascending and 'desc' for descending (default is 'asc')
 *     responses:
 *       200:
 *         description: Paginated CVE details
 *       500:
 *         description: Internal server error
 */
app.get('/api/cve', async (req, res) => {
  const limit = parseInt(req.query.limit) || 10;
  const page = parseInt(req.query.page) || 1;
  const sortField = req.query.sortField || 'publishedDate';
  const sortOrder = req.query.sortOrder === 'desc' ? -1 : 1;

  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  try {
    const totalRecords = await collection.countDocuments();
    const cveDetails = await collection.find()
      .sort({ [sortField]: sortOrder })
      .skip((page - 1) * limit)
      .limit(limit)
      .toArray();
      
    return res.json({
      cves: cveDetails,
      totalRecords
    });
  } catch (error) {
    console.error('Error fetching CVE details:', error);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// Endpoint to display CVE list
app.get('/cves/list', async (req, res) => {
  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  try {
    const cves = await collection.find().toArray();
    res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>CVE List</title>
      <style>
        body {
          font-family: Arial, sans-serif;
        }
        table {
          width: 100%;
          border-collapse: collapse;
        }
        th, td {
          padding: 8px 12px;
          border: 1px solid #ddd;
          text-align: left;
        }
        th {
          background-color: #f4f4f4;
        }
        .header {
          display: flex;
          justify-content: center;
          align-items: center;
          margin-bottom: 20px;
        }
        .total-records {
          margin-bottom: 20px;
          text-align: left;
        }
        .pagination {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 20px;
          text-align: left;
        }
        .pagination .left, .pagination .right {
          display: flex;
          align-items: center;
        }
        .pagination button {
          padding: 5px 10px;
          margin: 0 5px;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>CVE LIST</h1>
      </div>
      <div class="total-records">
        <span><b>Total Records: </b><span id="total-records">0</span></span>
        <br>
      </div>
      <table>
        <thead>
          <tr>
            <th>CVE ID</th>
            <th>IDENTIFIER</th>
            <th>PUBLISHED DATE</th>
            <th>LAST MODIFIED DATE</th>
            <th>STATUS</th>
          </tr>
        </thead>
        <tbody id="cve-table-body">
          <!-- CVE Data will be inserted here -->
        </tbody>
      </table>
      <div class="pagination">
        <div class="left">
          <label for="resultsPerPage"><b>Results Per Page:<b></label>
          <select id="resultsPerPage">
            <option value="10">10</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <div class="right">
          <button id="prevPage">Previous</button>
          <span id="pageIndicator">Page 1</span>
          <button id="nextPage">Next</button>
        </div>
      </div>
      <script>
        let currentPage = 1;
        let totalPages = 1;

        function formatDate(dateString) {
          const date = new Date(dateString);
          const day = date.getDate().toString().padStart(2, '0');
          const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
          const month = monthNames[date.getMonth()];
          const year = date.getFullYear();
          return \`\${day} \${month} \${year}\`;
        }

        async function fetchCVEData(limit = 10, page = 1) {
          try {
            const response = await fetch(\`/api/cve?limit=\${limit}&page=\${page}\`);
            const data = await response.json();
            displayCVEData(data.cves, data.totalRecords);
            totalPages = Math.ceil(data.totalRecords / limit);
            document.getElementById('pageIndicator').textContent = \`Page \${page} of \${totalPages}\`;
          } catch (error) {
            console.error('Error fetching CVE data:', error);
          }
        }

        function displayCVEData(cveData, totalRecords) {
          const tableBody = document.getElementById('cve-table-body');
          tableBody.innerHTML = '';
          cveData.forEach(cve => {
            const row = document.createElement('tr');
            row.innerHTML = \`
              <td>\${cve.cveId}</td>
              <td>\${cve.cve.sourceIdentifier}</td>
              <td>\${formatDate(cve.publishedDate)}</td>
              <td>\${formatDate(cve.lastModifiedDate)}</td>
              <td>\${cve.cve.vulnStatus}</td>
            \`;
            row.addEventListener('click', () => {
              window.location.href = \`/cves/\${cve.cveId}\`;
            });
            tableBody.appendChild(row);
          });
          document.getElementById('total-records').textContent = totalRecords;
        }

        document.getElementById('resultsPerPage').addEventListener('change', function() {
          const limit = parseInt(this.value);
          fetchCVEData(limit, 1);
        });

        document.getElementById('prevPage').addEventListener('click', () => {
          if (currentPage > 1) {
            currentPage--;
            fetchCVEData(parseInt(document.getElementById('resultsPerPage').value), currentPage);
          }
        });

        document.getElementById('nextPage').addEventListener('click', () => {
          if (currentPage < totalPages) {
            currentPage++;
            fetchCVEData(parseInt(document.getElementById('resultsPerPage').value), currentPage);
          }
        });

        // Initial fetch
        fetchCVEData();
      </script>
    </body>
    </html>
  `);
} catch (error) {
  console.error('Error fetching CVE list:', error);
  res.status(500).send('<h1>Internal server error</h1>');
}
});

// Endpoint to display CVE details
app.get('/cves/:cveId', async (req, res) => {
  const cveId = req.params.cveId;
  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  try {
    const cveDetails = await collection.findOne({ "cveId": cveId });
    if (!cveDetails) {
      return res.status(404).send('<h1>CVE not found</h1>');
    }

    // CVSS V2 Metrics
    const cvssV2Metrics = cveDetails.cve.metrics?.cvssMetricV2?.[0]?.cvssData || {};
    const severity = cveDetails.cve.metrics?.cvssMetricV2?.[0]?.baseSeverity || 'N/A';
    const exploitabilityScore = cveDetails.cve.metrics?.cvssMetricV2?.[0]?.exploitabilityScore || 'N/A';
    const impactScore = cveDetails.cve.metrics?.cvssMetricV2?.[0]?.impactScore || 'N/A';

    const cvssV2HTML = `
    <br>
      <h3>CVSS V2 Metrics:</h3>
      <p><b>Severity:</b> ${severity}</p>
      <p><b>Score:</b> ${cvssV2Metrics.baseScore || 'N/A'}</p>
      <p><b>Vector String:</b> ${cvssV2Metrics.vectorString || 'N/A'}</p>
      <table>
        <tr>
          <th>Access Vector</th>
          <th>Access Complexity</th>
          <th>Authentication</th>
          <th>Confidentiality Impact</th>
          <th>Integrity Impact</th>
          <th>Availability Impact</th>
        </tr>
        <tr>
          <td>${cvssV2Metrics.accessVector || 'N/A'}</td>
          <td>${cvssV2Metrics.accessComplexity || 'N/A'}</td>
          <td>${cvssV2Metrics.authentication || 'N/A'}</td>
          <td>${cvssV2Metrics.confidentialityImpact || 'N/A'}</td>
          <td>${cvssV2Metrics.integrityImpact || 'N/A'}</td>
          <td>${cvssV2Metrics.availabilityImpact || 'N/A'}</td>
        </tr>
      </table>
      <br>
      <h3><b>Scores:</b></h3>
      <p><b>Exploitability Score:</b> ${exploitabilityScore}</p>
      <p><b>Impact Score:</b>${impactScore}</p>
    `;

    // CPE Details
    const configurations = cveDetails.cve.configurations || [];
    let cpeHTML = `
    <br>
      <h3>CPE Details:</h3>
      <table>
        <tr>
          <th>Criteria</th>
          <th>Match Criteria ID</th>
          <th>Vulnerable</th>
        </tr>
    `;

    configurations.forEach(config => {
      config.nodes.forEach(node => {
        node.cpeMatch.forEach(cpe => {
          cpeHTML += `
            <tr>
              <td>${cpe.criteria || 'N/A'}</td>
              <td>${cpe.matchCriteriaId || 'N/A'}</td>
              <td>${cpe.vulnerable ? 'Yes' : 'No'}</td>
            </tr>
          `;
        });
      });
    });

    cpeHTML += '</table>';

    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${cveDetails.cveId}</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            padding: 20px;
          }
          h1 {
            font-size: 24px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }
          th, td {
            padding: 8px 12px;
            border: 1px solid #ddd;
            text-align: left;
          }
          th {
            background-color: #f4f4f4;
          }
        </style>
      </head>
      <body>
        <h1>${cveDetails.cveId}</h1>
        <br>
        <h1>Description:</h1>
        <p>${cveDetails.cve.descriptions[0]?.value || 'No description available'}</p>
        ${cvssV2HTML}
        ${cpeHTML}
      </body>
      </html>
    `);
  } catch (error) {
    console.error('Error fetching CVE details:', error);
    res.status(500).send('<h1>Internal server error</h1>');
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log(`Open your browser and navigate to http://localhost:${PORT}/cves/list to view the CVE list`);
});

export { app as default };

