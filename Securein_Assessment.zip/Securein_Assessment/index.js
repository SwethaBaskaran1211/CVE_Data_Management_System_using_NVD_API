import express from 'express';
import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import cron from 'node-schedule';
import fetch from 'node-fetch';
import { MongoClient } from 'mongodb';

const uri = "mongodb://localhost:27017/";
const dbName = "NVD";
const collectionName = "cve";
const port = 3000;

const app = express();

/**
 * Fetch CVE data from the NVD API.
 * 
 * @param {number} startIndex - The index to start fetching from.
 * @param {number} resultsPerPage - The number of results to fetch per page.
 * @returns {Object} The fetched CVE data.
 * @throws Will throw an error if the network response is not ok.
 */
async function fetchCVEData(startIndex = 0, resultsPerPage = 2000) {
  const url = `https://services.nvd.nist.gov/rest/json/cves/2.0?resultsPerPage=${resultsPerPage}&startIndex=${startIndex}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`HTTP error! Status: ${response.status}`);
  }
  const data = await response.json();
  return data;
}

/**
 * Store CVE data in the MongoDB collection.
 * 
 * @param {Array} cveData - The array of CVE data to store.
 */
async function storeCVEData(cveData) {
  const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
  await client.connect();

  try {
    const db = client.db(dbName);
    const collection = db.collection(collectionName);

    for (const cve of cveData) {
      if (checkForNullValues(cve)) {
        console.error('Invalid CVE data:', cve);
        continue;
      }

      const existingCVE = await collection.findOne({ "cveId": cve.cveId });
      if (existingCVE) {
        console.log(`Skipping duplicate CVE ID: ${cve.cveId}`);
        continue; // Skip insertion if duplicate CVE ID is found
      }

      await collection.insertOne(cve);
    }
  } catch (error) {
    console.error('Error storing CVE data:', error);
  } finally {
    await client.close();
  }
}

/**
 * Check for null or undefined values in the CVE data.
 * 
 * @param {Object} vulnerability - The CVE data object to check.
 * @returns {boolean} True if any value is null or undefined, false otherwise.
 */
function checkForNullValues(vulnerability) {
  return Object.values(vulnerability).some(value => value === null || value === undefined);
}

/**
 * Synchronize CVE data from the NVD API to the MongoDB collection.
 */
async function synchronizeCVEData() {
  const resultsPerPage = 2000;
  let startIndex = 0;
  let totalResults = 1;

  while (startIndex < totalResults) {
    try {
      const data = await fetchCVEData(startIndex, resultsPerPage);
      if (data.totalResults) {
        totalResults = data.totalResults;
      }

      const cveData = data.vulnerabilities || [];
      const transformedData = cveData.map(vul => ({
        cveId: vul.cve.id,
        description: vul.cve.descriptions[0]?.value || 'No description available',
        publishedDate: vul.cve.published,
        lastModifiedDate: vul.cve.lastModified,
        ...vul
      }));

      await storeCVEData(transformedData);

      startIndex += resultsPerPage;
    } catch (error) {
      console.error('Error synchronizing CVE data:', error);
    }
  }
}

// Schedule the synchronization job to run periodically at midnight
cron.scheduleJob('0 0 * * *', async () => {
  console.log('Running CVE synchronization job (incremental refresh)...');
  await synchronizeCVEData();
  console.log('CVE synchronization job (incremental refresh) complete.');
});

// Execute the initial synchronization
console.log('Running initial CVE synchronization job (full data refresh)...');
await synchronizeCVEData();
console.log('Initial CVE synchronization job (full data refresh) complete.');

/**
 * @swagger
 * /sync:
 *   get:
 *     summary: Trigger manual CVE data synchronization.
 *     responses:
 *       200:
 *         description: CVE data synchronization initiated.
 *       500:
 *         description: Server error.
 */
app.get('/sync', async (req, res) => {
  try {
    await synchronizeCVEData();
    res.status(200).send('CVE data synchronization initiated.');
  } catch (error) {
    console.error('Error during manual synchronization:', error);
    res.status(500).send('Server error.');
  }
});

// Swagger setup
const swaggerOptions = {
  swaggerDefinition: {
    openapi: '3.0.0',
    info: {
      title: 'CVE Data Synchronization API',
      version: '1.0.0',
      description: 'API documentation for CVE data synchronization service.'
    },
    servers: [
      {
        url: `http://localhost:${port}`
      }
    ]
  },
  apis: ['./index.js']
};

const swaggerDocs = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
  console.log(`Swagger docs available at http://localhost:${port}/api-docs`);
});


